#!/bin/bash

echo "Start model training and prediction..."
python test_binary_class/scripts/binary.py

echo "Done..."



