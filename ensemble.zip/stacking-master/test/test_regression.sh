#!/bin/bash

echo "Start model training and prediction..."
python test_regression/scripts/regression.py

echo "Done..."



