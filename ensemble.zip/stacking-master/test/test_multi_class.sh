#!/bin/bash

echo "Start model training and prediction..."
python test_multi_class/scripts/multiclass.py

echo "Done..."



