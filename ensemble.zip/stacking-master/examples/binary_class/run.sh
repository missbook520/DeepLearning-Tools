#!/bin/bash

echo "Start model training and prediction..."
python scripts/binary.py

echo "Done..."



