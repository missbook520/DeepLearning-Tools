#!/bin/bash

echo "Start model training and prediction..."
python scripts/regression.py

echo "Done..."



