#!/bin/bash

echo "Start model training and prediction..."
python scripts/multiclass.py

echo "Done..."



